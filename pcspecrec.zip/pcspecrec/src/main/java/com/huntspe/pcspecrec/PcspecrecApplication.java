package com.huntspe.pcspecrec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcspecrecApplication {

	public static void main(String[] args) {
		SpringApplication.run(PcspecrecApplication.class, args);
	}

}
